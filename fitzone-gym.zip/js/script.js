function validarLogin() {
  const usuario = document.getElementById("usuario").value;
  const password = document.getElementById("password").value;
  if (usuario === "admin" && password === "1234") {
    alert("¡Inicio de sesión exitoso!");
    window.location.href = "nosotros.html";
    return false;
  } else {
    alert("Usuario o contraseña incorrectos. Intenta nuevamente.");
    return false;
  }
}